
/* 
 * Program to compute the barycentric weights for channel flow DB
 * interpolation. The weight calculation are based on Prof. Greg Eyink's Matlab
 * scripts.
 *
 * Date: 2013-10-18
 *
 * Written by:
 *   Jason Graham <jgraha8@gmail.com>
 */


#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "hdf5.h"

#define H5_GRID_FILE "/home/jgraham/data/esdns/re1000/tdbchannel/grid.h5"

/* These are not type safe */
/* #define MAX(a,b) (a<b ? b : a ) */
/* #define MIN(a,b) (a<b ? a : b ) */

/* Local function prototypes */
void baryctrwt_uniform( int q, double dx, double *w );
void baryctrwt( int q, double *x, double *w );
void baryctrwt_uniform_write( const char *fname, int q, double *w );
void baryctrwt_write_header( FILE *fid, int q );
void baryctrwt_write_line( FILE *fid, int j, int j_s, int j_o, int q, double *w );

hid_t h5_file_open( const char *fname );
void h5_file_close( hid_t fid );
size_t h5_dataset_npoints( hid_t fid, const char *dataset );
void h5_dataset_read( hid_t fid, const char *dataset, double *field );

/*********************************************************************/
int main() 
/*********************************************************************/
{

	hid_t grid_fid = h5_file_open( H5_GRID_FILE );

	/* Check the grid sizes */
	const size_t Nx = h5_dataset_npoints( grid_fid, "x" );
	const size_t Ny = h5_dataset_npoints( grid_fid, "y" );
	const size_t Nz = h5_dataset_npoints( grid_fid, "z" );

	printf("Nx, Ny, Nz = %zd, %zd, %zd\n", Nx, Ny, Nz);

	// Allocate the grid arrays
	double *x = (double *)malloc(sizeof(double)*Nx);
	double *y = (double *)malloc(sizeof(double)*Ny);
	double *z = (double *)malloc(sizeof(double)*Nz);

	// Read the grids from file
	h5_dataset_read( grid_fid, "x", x );
	h5_dataset_read( grid_fid, "y", y );
	h5_dataset_read( grid_fid, "z", z );

	// Set the uniform grid spacing
	const double dx = x[1] - x[0];
	const double dz = z[1] - z[0];

	/* size_t i; */
	/* for( i=0; i<Nx; i++ ) { */
	/* 	printf("x[%zd] = %.16f\n", i, x[i]); */
	/* } */

	int q=0;
	for (q=4; q<=8; q+=2 ) {

		char x_weight_file_name[80];
		char y_weight_file_name[80];
		char z_weight_file_name[80];

		sprintf( x_weight_file_name, "baryctrwt-x-q-%d.dat", q);
		sprintf( z_weight_file_name, "baryctrwt-z-q-%d.dat", q);
		sprintf( y_weight_file_name, "baryctrwt-y-q-%d.dat", q);
		
		double *w = (double*)malloc(sizeof(double) * q );

		// X barycentric weights
		baryctrwt_uniform( q, dx, w );		
		baryctrwt_uniform_write( x_weight_file_name, q, w );

		// Z barycentric weights
		baryctrwt_uniform( q, dz, w );		
		baryctrwt_uniform_write( z_weight_file_name, q, w );

		// Y barycentric weights
		FILE *y_weight_fid = fopen( y_weight_file_name, "w" );
		baryctrwt_write_header( y_weight_fid, q );

		size_t i=0;
		for( i=0; i<Ny-1; i++ ) {

			int j_o = 0;
			const int q2 = q/2;
			// Compute j_o (index offset)
			if( i <= Ny/2 - 1 ) {
				//j_o = MAX(q2-i-1,0);
				j_o = q2-i-1;
				if( j_o < 0 ) j_o = 0;
			} else {
				//j_o = MIN(Ny-1-i-q2,0);
				j_o = Ny-1-i-q2;
				if( j_o > 0 ) j_o = 0;
			}

			// Compute j_s (starting index)
			int j_s = i - q2 + 1 + j_o;

			assert( j_s >= 0 );
			
			baryctrwt( q, y+j_s, w );
			baryctrwt_write_line( y_weight_fid, i, j_s, j_o, q, w );

		}
		fclose(y_weight_fid);

		free(w);

	}


	h5_file_close( grid_fid );

	free(x);
	free(y);
	free(z);

	return 0;
	
}

/********************************************************************/
void baryctrwt( int q, double *x, double *w ) 
/********************************************************************/
{
	int i,j;

	for( i=0; i<q; i++ ) w[i]=1.0L;

	for (i=1; i<q; i++ ) {
		for( j=0; j<i-1; j++ ) {
			w[j] = (x[j] - x[i])*w[j];
			w[i] = (x[i] - x[j])*w[i];
		}
	}
	for( i=0; i<q; i++ ) w[i]=1.0L / w[i];

	return;
}

/********************************************************************/
void baryctrwt_uniform( int q, double dx, double *w ) 
/********************************************************************/
{
	int i,j;

	for( i=0; i<q; i++ ) w[i]=1.0L;

	for (i=1; i<q; i++ ) {
		for( j=0; j<i-1; j++ ) {
			w[j] = (j - i)*dx*w[j];
			w[i] = (i - j)*dx*w[i];
		}
	}
	for( i=0; i<q; i++ ) w[i]=1.0L / w[i];

	return;
}

/*********************************************************************/
void baryctrwt_uniform_write( const char *fname, int q, double *w )
/*********************************************************************/
{
	FILE *weight_file = fopen(fname,"w");

	int i=0;

	/* First line is a comment so starts with # */
	fprintf(weight_file,"# ");
	for( i=0; i<q-1; i++ ) fprintf(weight_file, "w[%d], ", i );
	fprintf(weight_file, "w[%d]\n",q-1);
	for( i=0; i<q-1; i++ ) fprintf(weight_file, "%.16f ", w[i]);
	fprintf(weight_file, "%.16f\n", w[q-1]);
	fclose(weight_file);
		
}

/*********************************************************************/
void baryctrwt_write_header( FILE *fid, int q )
/*********************************************************************/
{
	int i=0;

	/* First line is a comment so starts with # */
	fprintf(fid, "# j, j_s, j_o, ");
	for( i=0; i<q-1; i++ ) fprintf(fid, "w[%d], ", i );
	fprintf(fid, "w[%d]\n",q-1);

}

/*********************************************************************/
void baryctrwt_write_line( FILE *fid, int j, int j_s, int j_o, int q, double *w )
/*********************************************************************/
{
	int i=0;
	fprintf(fid, "%d, %d, %d, ", j, j_s, j_o);
	for( i=0; i<q-1; i++ ) fprintf(fid, "%.16f ", w[i]);
	fprintf(fid, "%.16f\n", w[q-1]);
	
}

/*********************************************************************/
hid_t h5_file_open( const char *fname )
/*********************************************************************/
/*
  This function opens the specified file and creates a new h5file_t
  object
 */
{
	return H5Fopen (fname, H5F_ACC_RDONLY, H5P_DEFAULT);
}

/********************************************************************/
void h5_file_close( hid_t fid )
/********************************************************************/
{
	H5Fclose( fid );
	return;
}


/*********************************************************************/
size_t h5_dataset_npoints( hid_t fid, const char *dataset )
/*********************************************************************/
{

  hid_t dd; // Dataset handle
  hid_t ds; // Dataspace handle
  
  hssize_t npoints;

  // Dataset info
  dd = H5Dopen2(fid, dataset, H5P_DEFAULT);
  ds = H5Dget_space(dd);    /* dataspace handle */
  npoints = H5Sget_simple_extent_npoints( ds );

  H5Sclose(ds);
  H5Dclose(dd);

  return (size_t)npoints;

}


/*********************************************************************/
void h5_dataset_read( hid_t fid, const char *dataset, double *field )
/*********************************************************************/
{

  herr_t status;
  hid_t dd; /* Dataset handle */
  hid_t ds; /* Dataspace handle */
  hid_t dt; /* Datatype handle */
  hid_t dt_native; /* Datatype native type */

    // Dataset info
  dd = H5Dopen2(fid, dataset, H5P_DEFAULT);
  ds = H5Dget_space(dd);    /* dataspace handle */
  dt = H5Dget_type(dd);     /* datatype handle */
  dt_native = H5Tget_native_type(dt, H5T_DIR_ASCEND);
  status = H5Dread(dd, dt_native, H5S_ALL, ds, H5P_DEFAULT, field);

  H5Tclose(dt_native);
  H5Tclose(dt);
  H5Sclose(ds);
  H5Dclose(dd);

  return;

}

