--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.jhtdb_polycache DROP CONSTRAINT jhtdb_polycache_dataset_id_5493d826fcf123c3_fk_jhtdb_dataset_id;
ALTER TABLE ONLY public.jhtdb_datafield_dataset DROP CONSTRAINT jhtdb_dataf_datafield_id_68c411ecbdbe208c_fk_jhtdb_datafield_id;
ALTER TABLE ONLY public.jhtdb_datafield_dataset DROP CONSTRAINT jhtdb_dafafield_dataset_id_6ddbbb10c454612c_fk_jhtdb_dataset_id;
ALTER TABLE ONLY public.djcelery_taskstate DROP CONSTRAINT djcelery__worker_id_30050731b1c3d3d9_fk_djcelery_workerstate_id;
ALTER TABLE ONLY public.djcelery_periodictask DROP CONSTRAINT djce_crontab_id_1d8228f5b44b680a_fk_djcelery_crontabschedule_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT djan_content_type_id_697914295151027a_fk_django_content_type_id;
ALTER TABLE ONLY public.djcelery_periodictask DROP CONSTRAINT dj_interval_id_20cfc1cad060dfad_fk_djcelery_intervalschedule_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permiss_user_id_7f0938558328534a_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_4b5ed4ffdb8fd9b0_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user__permission_id_384b62483d7071f0_fk_auth_permission_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissio_group_id_689710a9a73b7457_fk_auth_group_id;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_content_type_id_508cf46651277a81_fk_django_content_type_id;
DROP INDEX public.jhtdb_polycache_d366d308;
DROP INDEX public.jhtdb_dafafield_dataset_d366d308;
DROP INDEX public.jhtdb_dafafield_dataset_0b1f13d3;
DROP INDEX public.djcelery_workerstate_hostname_3900851044588416_like;
DROP INDEX public.djcelery_workerstate_f129901a;
DROP INDEX public.djcelery_taskstate_task_id_29366bc6dcd6fd60_like;
DROP INDEX public.djcelery_taskstate_state_19cb9b39780e399c_like;
DROP INDEX public.djcelery_taskstate_name_4337b4449e8827d_like;
DROP INDEX public.djcelery_taskstate_ce77e6ef;
DROP INDEX public.djcelery_taskstate_b068931c;
DROP INDEX public.djcelery_taskstate_9ed39e2e;
DROP INDEX public.djcelery_taskstate_863bb2ee;
DROP INDEX public.djcelery_taskstate_662f707d;
DROP INDEX public.djcelery_periodictask_name_47c621f8dc029d22_like;
DROP INDEX public.djcelery_periodictask_f3f0d72a;
DROP INDEX public.djcelery_periodictask_1dcd7040;
DROP INDEX public.django_session_session_key_461cfeaa630ca218_like;
DROP INDEX public.django_session_de54fa62;
DROP INDEX public.django_admin_log_e8701ad4;
DROP INDEX public.django_admin_log_417f1b1c;
DROP INDEX public.celery_tasksetmeta_taskset_id_24b26c359742c9ab_like;
DROP INDEX public.celery_tasksetmeta_662f707d;
DROP INDEX public.celery_taskmeta_task_id_1efd6ed1da631331_like;
DROP INDEX public.celery_taskmeta_662f707d;
DROP INDEX public.auth_user_username_51b3b110094b8aae_like;
DROP INDEX public.auth_user_user_permissions_e8701ad4;
DROP INDEX public.auth_user_user_permissions_8373b171;
DROP INDEX public.auth_user_groups_e8701ad4;
DROP INDEX public.auth_user_groups_0e939a4f;
DROP INDEX public.auth_permission_417f1b1c;
DROP INDEX public.auth_group_permissions_8373b171;
DROP INDEX public.auth_group_permissions_0e939a4f;
DROP INDEX public.auth_group_name_253ae2a6331666e8_like;
ALTER TABLE ONLY public.jhtdb_polycache DROP CONSTRAINT jhtdb_polycache_pkey;
ALTER TABLE ONLY public.jhtdb_dataset DROP CONSTRAINT jhtdb_dataset_pkey;
ALTER TABLE ONLY public.jhtdb_datafield DROP CONSTRAINT jhtdb_dafafield_pkey;
ALTER TABLE ONLY public.jhtdb_datafield_dataset DROP CONSTRAINT jhtdb_dafafield_dataset_pkey;
ALTER TABLE ONLY public.jhtdb_datafield_dataset DROP CONSTRAINT jhtdb_dafafield_dataset_dafafield_id_key;
ALTER TABLE ONLY public.djcelery_workerstate DROP CONSTRAINT djcelery_workerstate_pkey;
ALTER TABLE ONLY public.djcelery_workerstate DROP CONSTRAINT djcelery_workerstate_hostname_key;
ALTER TABLE ONLY public.djcelery_taskstate DROP CONSTRAINT djcelery_taskstate_task_id_key;
ALTER TABLE ONLY public.djcelery_taskstate DROP CONSTRAINT djcelery_taskstate_pkey;
ALTER TABLE ONLY public.djcelery_periodictasks DROP CONSTRAINT djcelery_periodictasks_pkey;
ALTER TABLE ONLY public.djcelery_periodictask DROP CONSTRAINT djcelery_periodictask_pkey;
ALTER TABLE ONLY public.djcelery_periodictask DROP CONSTRAINT djcelery_periodictask_name_key;
ALTER TABLE ONLY public.djcelery_intervalschedule DROP CONSTRAINT djcelery_intervalschedule_pkey;
ALTER TABLE ONLY public.djcelery_crontabschedule DROP CONSTRAINT djcelery_crontabschedule_pkey;
ALTER TABLE ONLY public.django_session DROP CONSTRAINT django_session_pkey;
ALTER TABLE ONLY public.django_migrations DROP CONSTRAINT django_migrations_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_app_label_45f3b1d93ec8c61c_uniq;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_pkey;
ALTER TABLE ONLY public.cutout_dataset DROP CONSTRAINT cutout_dataset_pkey;
ALTER TABLE ONLY public.celery_tasksetmeta DROP CONSTRAINT celery_tasksetmeta_taskset_id_key;
ALTER TABLE ONLY public.celery_tasksetmeta DROP CONSTRAINT celery_tasksetmeta_pkey;
ALTER TABLE ONLY public.celery_taskmeta DROP CONSTRAINT celery_taskmeta_task_id_key;
ALTER TABLE ONLY public.celery_taskmeta DROP CONSTRAINT celery_taskmeta_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_username_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_pkey;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_key;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_key;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_key;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_name_key;
ALTER TABLE public.jhtdb_polycache ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.jhtdb_datafield_dataset ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.jhtdb_datafield ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.djcelery_workerstate ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.djcelery_taskstate ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.djcelery_periodictask ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.djcelery_intervalschedule ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.djcelery_crontabschedule ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_content_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_admin_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.cutout_dataset ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.celery_tasksetmeta ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.celery_taskmeta ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_permission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.jhtdb_polycache_id_seq;
DROP TABLE public.jhtdb_polycache;
DROP SEQUENCE public.jhtdb_dataset_id_seq;
DROP TABLE public.jhtdb_dataset;
DROP SEQUENCE public.jhtdb_dafafield_id_seq;
DROP TABLE public.jhtdb_datafield;
DROP SEQUENCE public.jhtdb_dafafield_dataset_id_seq;
DROP TABLE public.jhtdb_datafield_dataset;
DROP SEQUENCE public.id_sequence;
DROP SEQUENCE public.djcelery_workerstate_id_seq;
DROP TABLE public.djcelery_workerstate;
DROP SEQUENCE public.djcelery_taskstate_id_seq;
DROP TABLE public.djcelery_taskstate;
DROP TABLE public.djcelery_periodictasks;
DROP SEQUENCE public.djcelery_periodictask_id_seq;
DROP TABLE public.djcelery_periodictask;
DROP SEQUENCE public.djcelery_intervalschedule_id_seq;
DROP TABLE public.djcelery_intervalschedule;
DROP SEQUENCE public.djcelery_crontabschedule_id_seq;
DROP TABLE public.djcelery_crontabschedule;
DROP TABLE public.django_session;
DROP SEQUENCE public.django_migrations_id_seq;
DROP TABLE public.django_migrations;
DROP SEQUENCE public.django_content_type_id_seq;
DROP TABLE public.django_content_type;
DROP SEQUENCE public.django_admin_log_id_seq;
DROP TABLE public.django_admin_log;
DROP SEQUENCE public.cutout_dataset_id_seq;
DROP TABLE public.cutout_dataset;
DROP SEQUENCE public.celery_tasksetmeta_id_seq;
DROP TABLE public.celery_tasksetmeta;
DROP SEQUENCE public.celery_taskmeta_id_seq;
DROP TABLE public.celery_taskmeta;
DROP SEQUENCE public.auth_user_user_permissions_id_seq;
DROP TABLE public.auth_user_user_permissions;
DROP SEQUENCE public.auth_user_id_seq;
DROP SEQUENCE public.auth_user_groups_id_seq;
DROP TABLE public.auth_user_groups;
DROP TABLE public.auth_user;
DROP SEQUENCE public.auth_permission_id_seq;
DROP TABLE public.auth_permission;
DROP SEQUENCE public.auth_group_permissions_id_seq;
DROP TABLE public.auth_group_permissions;
DROP SEQUENCE public.auth_group_id_seq;
DROP TABLE public.auth_group;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO djuser;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO djuser;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO djuser;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO djuser;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO djuser;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO djuser;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('auth_permission_id_seq', 54, true);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO djuser;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO djuser;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO djuser;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO djuser;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('auth_user_id_seq', 1, true);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO djuser;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO djuser;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Name: celery_taskmeta; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE celery_taskmeta (
    id integer NOT NULL,
    task_id character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    result text,
    date_done timestamp with time zone NOT NULL,
    traceback text,
    hidden boolean NOT NULL,
    meta text
);


ALTER TABLE public.celery_taskmeta OWNER TO djuser;

--
-- Name: celery_taskmeta_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE celery_taskmeta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.celery_taskmeta_id_seq OWNER TO djuser;

--
-- Name: celery_taskmeta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE celery_taskmeta_id_seq OWNED BY celery_taskmeta.id;


--
-- Name: celery_taskmeta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('celery_taskmeta_id_seq', 4137, true);


--
-- Name: celery_tasksetmeta; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE celery_tasksetmeta (
    id integer NOT NULL,
    taskset_id character varying(255) NOT NULL,
    result text NOT NULL,
    date_done timestamp with time zone NOT NULL,
    hidden boolean NOT NULL
);


ALTER TABLE public.celery_tasksetmeta OWNER TO djuser;

--
-- Name: celery_tasksetmeta_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE celery_tasksetmeta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.celery_tasksetmeta_id_seq OWNER TO djuser;

--
-- Name: celery_tasksetmeta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE celery_tasksetmeta_id_seq OWNED BY celery_tasksetmeta.id;


--
-- Name: celery_tasksetmeta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('celery_tasksetmeta_id_seq', 1, false);


--
-- Name: cutout_dataset; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE cutout_dataset (
    id integer NOT NULL,
    dataset_text character varying(200) NOT NULL,
    dbname_text character varying(30) NOT NULL
);


ALTER TABLE public.cutout_dataset OWNER TO djuser;

--
-- Name: cutout_dataset_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE cutout_dataset_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.cutout_dataset_id_seq OWNER TO djuser;

--
-- Name: cutout_dataset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE cutout_dataset_id_seq OWNED BY cutout_dataset.id;


--
-- Name: cutout_dataset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('cutout_dataset_id_seq', 1, false);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO djuser;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO djuser;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 2, true);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO djuser;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO djuser;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('django_content_type_id_seq', 18, true);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO djuser;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO djuser;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('django_migrations_id_seq', 23, true);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO djuser;

--
-- Name: djcelery_crontabschedule; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE djcelery_crontabschedule (
    id integer NOT NULL,
    minute character varying(64) NOT NULL,
    hour character varying(64) NOT NULL,
    day_of_week character varying(64) NOT NULL,
    day_of_month character varying(64) NOT NULL,
    month_of_year character varying(64) NOT NULL
);


ALTER TABLE public.djcelery_crontabschedule OWNER TO djuser;

--
-- Name: djcelery_crontabschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE djcelery_crontabschedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.djcelery_crontabschedule_id_seq OWNER TO djuser;

--
-- Name: djcelery_crontabschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE djcelery_crontabschedule_id_seq OWNED BY djcelery_crontabschedule.id;


--
-- Name: djcelery_crontabschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('djcelery_crontabschedule_id_seq', 1, false);


--
-- Name: djcelery_intervalschedule; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE djcelery_intervalschedule (
    id integer NOT NULL,
    every integer NOT NULL,
    period character varying(24) NOT NULL
);


ALTER TABLE public.djcelery_intervalschedule OWNER TO djuser;

--
-- Name: djcelery_intervalschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE djcelery_intervalschedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.djcelery_intervalschedule_id_seq OWNER TO djuser;

--
-- Name: djcelery_intervalschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE djcelery_intervalschedule_id_seq OWNED BY djcelery_intervalschedule.id;


--
-- Name: djcelery_intervalschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('djcelery_intervalschedule_id_seq', 1, false);


--
-- Name: djcelery_periodictask; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE djcelery_periodictask (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    task character varying(200) NOT NULL,
    args text NOT NULL,
    kwargs text NOT NULL,
    queue character varying(200),
    exchange character varying(200),
    routing_key character varying(200),
    expires timestamp with time zone,
    enabled boolean NOT NULL,
    last_run_at timestamp with time zone,
    total_run_count integer NOT NULL,
    date_changed timestamp with time zone NOT NULL,
    description text NOT NULL,
    crontab_id integer,
    interval_id integer,
    CONSTRAINT djcelery_periodictask_total_run_count_check CHECK ((total_run_count >= 0))
);


ALTER TABLE public.djcelery_periodictask OWNER TO djuser;

--
-- Name: djcelery_periodictask_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE djcelery_periodictask_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.djcelery_periodictask_id_seq OWNER TO djuser;

--
-- Name: djcelery_periodictask_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE djcelery_periodictask_id_seq OWNED BY djcelery_periodictask.id;


--
-- Name: djcelery_periodictask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('djcelery_periodictask_id_seq', 1, false);


--
-- Name: djcelery_periodictasks; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE djcelery_periodictasks (
    ident smallint NOT NULL,
    last_update timestamp with time zone NOT NULL
);


ALTER TABLE public.djcelery_periodictasks OWNER TO djuser;

--
-- Name: djcelery_taskstate; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE djcelery_taskstate (
    id integer NOT NULL,
    state character varying(64) NOT NULL,
    task_id character varying(36) NOT NULL,
    name character varying(200),
    tstamp timestamp with time zone NOT NULL,
    args text,
    kwargs text,
    eta timestamp with time zone,
    expires timestamp with time zone,
    result text,
    traceback text,
    runtime double precision,
    retries integer NOT NULL,
    hidden boolean NOT NULL,
    worker_id integer
);


ALTER TABLE public.djcelery_taskstate OWNER TO djuser;

--
-- Name: djcelery_taskstate_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE djcelery_taskstate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.djcelery_taskstate_id_seq OWNER TO djuser;

--
-- Name: djcelery_taskstate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE djcelery_taskstate_id_seq OWNED BY djcelery_taskstate.id;


--
-- Name: djcelery_taskstate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('djcelery_taskstate_id_seq', 1, false);


--
-- Name: djcelery_workerstate; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE djcelery_workerstate (
    id integer NOT NULL,
    hostname character varying(255) NOT NULL,
    last_heartbeat timestamp with time zone
);


ALTER TABLE public.djcelery_workerstate OWNER TO djuser;

--
-- Name: djcelery_workerstate_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE djcelery_workerstate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.djcelery_workerstate_id_seq OWNER TO djuser;

--
-- Name: djcelery_workerstate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE djcelery_workerstate_id_seq OWNED BY djcelery_workerstate.id;


--
-- Name: djcelery_workerstate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('djcelery_workerstate_id_seq', 1, false);


--
-- Name: id_sequence; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE id_sequence
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.id_sequence OWNER TO djuser;

--
-- Name: id_sequence; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('id_sequence', 6, true);


--
-- Name: jhtdb_datafield_dataset; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE jhtdb_datafield_dataset (
    id integer NOT NULL,
    datafield_id integer NOT NULL,
    dataset_id integer NOT NULL
);


ALTER TABLE public.jhtdb_datafield_dataset OWNER TO djuser;

--
-- Name: jhtdb_dafafield_dataset_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE jhtdb_dafafield_dataset_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.jhtdb_dafafield_dataset_id_seq OWNER TO djuser;

--
-- Name: jhtdb_dafafield_dataset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE jhtdb_dafafield_dataset_id_seq OWNED BY jhtdb_datafield_dataset.id;


--
-- Name: jhtdb_dafafield_dataset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('jhtdb_dafafield_dataset_id_seq', 8, true);


--
-- Name: jhtdb_datafield; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE jhtdb_datafield (
    id integer NOT NULL,
    longname character varying(50) NOT NULL,
    shortname character varying(1) NOT NULL,
    components integer NOT NULL
);


ALTER TABLE public.jhtdb_datafield OWNER TO djuser;

--
-- Name: jhtdb_dafafield_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE jhtdb_dafafield_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.jhtdb_dafafield_id_seq OWNER TO djuser;

--
-- Name: jhtdb_dafafield_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE jhtdb_dafafield_id_seq OWNED BY jhtdb_datafield.id;


--
-- Name: jhtdb_dafafield_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('jhtdb_dafafield_id_seq', 1, false);


--
-- Name: jhtdb_dataset; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE jhtdb_dataset (
    id integer DEFAULT nextval('id_sequence'::regclass) NOT NULL,
    dataset_text character varying(50) NOT NULL,
    dbname_text character varying(30) NOT NULL,
    xstart integer NOT NULL,
    ystart integer NOT NULL,
    zstart integer NOT NULL,
    xend integer NOT NULL,
    yend integer NOT NULL,
    zend integer NOT NULL,
    timeend integer NOT NULL,
    tstart integer NOT NULL,
    defaultthreshold double precision NOT NULL,
    timefactor integer NOT NULL,
    xspacing double precision NOT NULL,
    yspacing double precision NOT NULL,
    zspacing double precision NOT NULL,
    dt double precision NOT NULL
);


ALTER TABLE public.jhtdb_dataset OWNER TO djuser;

--
-- Name: jhtdb_dataset_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE jhtdb_dataset_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.jhtdb_dataset_id_seq OWNER TO djuser;

--
-- Name: jhtdb_dataset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE jhtdb_dataset_id_seq OWNED BY jhtdb_dataset.id;


--
-- Name: jhtdb_dataset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('jhtdb_dataset_id_seq', 5, true);


--
-- Name: jhtdb_polycache; Type: TABLE; Schema: public; Owner: djuser; Tablespace: 
--

CREATE TABLE jhtdb_polycache (
    id integer NOT NULL,
    zindexstart integer NOT NULL,
    zindexend integer NOT NULL,
    filename character varying(50) NOT NULL,
    compute_time integer NOT NULL,
    threshold double precision NOT NULL,
    timestep integer NOT NULL,
    computation character varying(5) NOT NULL,
    dataset_id integer NOT NULL,
    filterwidth integer NOT NULL
);


ALTER TABLE public.jhtdb_polycache OWNER TO djuser;

--
-- Name: jhtdb_polycache_id_seq; Type: SEQUENCE; Schema: public; Owner: djuser
--

CREATE SEQUENCE jhtdb_polycache_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.jhtdb_polycache_id_seq OWNER TO djuser;

--
-- Name: jhtdb_polycache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: djuser
--

ALTER SEQUENCE jhtdb_polycache_id_seq OWNED BY jhtdb_polycache.id;


--
-- Name: jhtdb_polycache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: djuser
--

SELECT pg_catalog.setval('jhtdb_polycache_id_seq', 1, false);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY celery_taskmeta ALTER COLUMN id SET DEFAULT nextval('celery_taskmeta_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY celery_tasksetmeta ALTER COLUMN id SET DEFAULT nextval('celery_tasksetmeta_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY cutout_dataset ALTER COLUMN id SET DEFAULT nextval('cutout_dataset_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY djcelery_crontabschedule ALTER COLUMN id SET DEFAULT nextval('djcelery_crontabschedule_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY djcelery_intervalschedule ALTER COLUMN id SET DEFAULT nextval('djcelery_intervalschedule_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY djcelery_periodictask ALTER COLUMN id SET DEFAULT nextval('djcelery_periodictask_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY djcelery_taskstate ALTER COLUMN id SET DEFAULT nextval('djcelery_taskstate_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY djcelery_workerstate ALTER COLUMN id SET DEFAULT nextval('djcelery_workerstate_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY jhtdb_datafield ALTER COLUMN id SET DEFAULT nextval('jhtdb_dafafield_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY jhtdb_datafield_dataset ALTER COLUMN id SET DEFAULT nextval('jhtdb_dafafield_dataset_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY jhtdb_polycache ALTER COLUMN id SET DEFAULT nextval('jhtdb_polycache_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY auth_group (id, name) FROM stdin;
\.
COPY auth_group (id, name) FROM '$$PATH$$/2054.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/2055.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/2053.dat';

--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.
COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM '$$PATH$$/2056.dat';

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY auth_user_groups (id, user_id, group_id) FROM '$$PATH$$/2057.dat';

--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY auth_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/2058.dat';

--
-- Data for Name: celery_taskmeta; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY celery_taskmeta (id, task_id, status, result, date_done, traceback, hidden, meta) FROM stdin;
\.
COPY celery_taskmeta (id, task_id, status, result, date_done, traceback, hidden, meta) FROM '$$PATH$$/2064.dat';

--
-- Data for Name: celery_tasksetmeta; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY celery_tasksetmeta (id, taskset_id, result, date_done, hidden) FROM stdin;
\.
COPY celery_tasksetmeta (id, taskset_id, result, date_done, hidden) FROM '$$PATH$$/2065.dat';

--
-- Data for Name: cutout_dataset; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY cutout_dataset (id, dataset_text, dbname_text) FROM stdin;
\.
COPY cutout_dataset (id, dataset_text, dbname_text) FROM '$$PATH$$/2073.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/2059.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY django_content_type (id, app_label, model) FROM stdin;
\.
COPY django_content_type (id, app_label, model) FROM '$$PATH$$/2052.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY django_migrations (id, app, name, applied) FROM stdin;
\.
COPY django_migrations (id, app, name, applied) FROM '$$PATH$$/2051.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY django_session (session_key, session_data, expire_date) FROM '$$PATH$$/2072.dat';

--
-- Data for Name: djcelery_crontabschedule; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY djcelery_crontabschedule (id, minute, hour, day_of_week, day_of_month, month_of_year) FROM stdin;
\.
COPY djcelery_crontabschedule (id, minute, hour, day_of_week, day_of_month, month_of_year) FROM '$$PATH$$/2060.dat';

--
-- Data for Name: djcelery_intervalschedule; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY djcelery_intervalschedule (id, every, period) FROM stdin;
\.
COPY djcelery_intervalschedule (id, every, period) FROM '$$PATH$$/2061.dat';

--
-- Data for Name: djcelery_periodictask; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY djcelery_periodictask (id, name, task, args, kwargs, queue, exchange, routing_key, expires, enabled, last_run_at, total_run_count, date_changed, description, crontab_id, interval_id) FROM stdin;
\.
COPY djcelery_periodictask (id, name, task, args, kwargs, queue, exchange, routing_key, expires, enabled, last_run_at, total_run_count, date_changed, description, crontab_id, interval_id) FROM '$$PATH$$/2062.dat';

--
-- Data for Name: djcelery_periodictasks; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY djcelery_periodictasks (ident, last_update) FROM stdin;
\.
COPY djcelery_periodictasks (ident, last_update) FROM '$$PATH$$/2063.dat';

--
-- Data for Name: djcelery_taskstate; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY djcelery_taskstate (id, state, task_id, name, tstamp, args, kwargs, eta, expires, result, traceback, runtime, retries, hidden, worker_id) FROM stdin;
\.
COPY djcelery_taskstate (id, state, task_id, name, tstamp, args, kwargs, eta, expires, result, traceback, runtime, retries, hidden, worker_id) FROM '$$PATH$$/2066.dat';

--
-- Data for Name: djcelery_workerstate; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY djcelery_workerstate (id, hostname, last_heartbeat) FROM stdin;
\.
COPY djcelery_workerstate (id, hostname, last_heartbeat) FROM '$$PATH$$/2067.dat';

--
-- Data for Name: jhtdb_datafield; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY jhtdb_datafield (id, longname, shortname, components) FROM stdin;
\.
COPY jhtdb_datafield (id, longname, shortname, components) FROM '$$PATH$$/2068.dat';

--
-- Data for Name: jhtdb_datafield_dataset; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY jhtdb_datafield_dataset (id, datafield_id, dataset_id) FROM stdin;
\.
COPY jhtdb_datafield_dataset (id, datafield_id, dataset_id) FROM '$$PATH$$/2070.dat';

--
-- Data for Name: jhtdb_dataset; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY jhtdb_dataset (id, dataset_text, dbname_text, xstart, ystart, zstart, xend, yend, zend, timeend, tstart, defaultthreshold, timefactor, xspacing, yspacing, zspacing, dt) FROM stdin;
\.
COPY jhtdb_dataset (id, dataset_text, dbname_text, xstart, ystart, zstart, xend, yend, zend, timeend, tstart, defaultthreshold, timefactor, xspacing, yspacing, zspacing, dt) FROM '$$PATH$$/2069.dat';

--
-- Data for Name: jhtdb_polycache; Type: TABLE DATA; Schema: public; Owner: djuser
--

COPY jhtdb_polycache (id, zindexstart, zindexend, filename, compute_time, threshold, timestep, computation, dataset_id, filterwidth) FROM stdin;
\.
COPY jhtdb_polycache (id, zindexstart, zindexend, filename, compute_time, threshold, timestep, computation, dataset_id, filterwidth) FROM '$$PATH$$/2071.dat';

--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_key; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_key; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_key; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_key; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: celery_taskmeta_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY celery_taskmeta
    ADD CONSTRAINT celery_taskmeta_pkey PRIMARY KEY (id);


--
-- Name: celery_taskmeta_task_id_key; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY celery_taskmeta
    ADD CONSTRAINT celery_taskmeta_task_id_key UNIQUE (task_id);


--
-- Name: celery_tasksetmeta_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY celery_tasksetmeta
    ADD CONSTRAINT celery_tasksetmeta_pkey PRIMARY KEY (id);


--
-- Name: celery_tasksetmeta_taskset_id_key; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY celery_tasksetmeta
    ADD CONSTRAINT celery_tasksetmeta_taskset_id_key UNIQUE (taskset_id);


--
-- Name: cutout_dataset_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY cutout_dataset
    ADD CONSTRAINT cutout_dataset_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_45f3b1d93ec8c61c_uniq; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_45f3b1d93ec8c61c_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: djcelery_crontabschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY djcelery_crontabschedule
    ADD CONSTRAINT djcelery_crontabschedule_pkey PRIMARY KEY (id);


--
-- Name: djcelery_intervalschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY djcelery_intervalschedule
    ADD CONSTRAINT djcelery_intervalschedule_pkey PRIMARY KEY (id);


--
-- Name: djcelery_periodictask_name_key; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY djcelery_periodictask
    ADD CONSTRAINT djcelery_periodictask_name_key UNIQUE (name);


--
-- Name: djcelery_periodictask_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY djcelery_periodictask
    ADD CONSTRAINT djcelery_periodictask_pkey PRIMARY KEY (id);


--
-- Name: djcelery_periodictasks_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY djcelery_periodictasks
    ADD CONSTRAINT djcelery_periodictasks_pkey PRIMARY KEY (ident);


--
-- Name: djcelery_taskstate_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY djcelery_taskstate
    ADD CONSTRAINT djcelery_taskstate_pkey PRIMARY KEY (id);


--
-- Name: djcelery_taskstate_task_id_key; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY djcelery_taskstate
    ADD CONSTRAINT djcelery_taskstate_task_id_key UNIQUE (task_id);


--
-- Name: djcelery_workerstate_hostname_key; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY djcelery_workerstate
    ADD CONSTRAINT djcelery_workerstate_hostname_key UNIQUE (hostname);


--
-- Name: djcelery_workerstate_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY djcelery_workerstate
    ADD CONSTRAINT djcelery_workerstate_pkey PRIMARY KEY (id);


--
-- Name: jhtdb_dafafield_dataset_dafafield_id_key; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY jhtdb_datafield_dataset
    ADD CONSTRAINT jhtdb_dafafield_dataset_dafafield_id_key UNIQUE (datafield_id, dataset_id);


--
-- Name: jhtdb_dafafield_dataset_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY jhtdb_datafield_dataset
    ADD CONSTRAINT jhtdb_dafafield_dataset_pkey PRIMARY KEY (id);


--
-- Name: jhtdb_dafafield_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY jhtdb_datafield
    ADD CONSTRAINT jhtdb_dafafield_pkey PRIMARY KEY (id);


--
-- Name: jhtdb_dataset_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY jhtdb_dataset
    ADD CONSTRAINT jhtdb_dataset_pkey PRIMARY KEY (id);


--
-- Name: jhtdb_polycache_pkey; Type: CONSTRAINT; Schema: public; Owner: djuser; Tablespace: 
--

ALTER TABLE ONLY jhtdb_polycache
    ADD CONSTRAINT jhtdb_polycache_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_253ae2a6331666e8_like; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX auth_group_name_253ae2a6331666e8_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX auth_group_permissions_0e939a4f ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX auth_group_permissions_8373b171 ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX auth_permission_417f1b1c ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX auth_user_groups_0e939a4f ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX auth_user_groups_e8701ad4 ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_8373b171 ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_e8701ad4 ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_51b3b110094b8aae_like; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX auth_user_username_51b3b110094b8aae_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: celery_taskmeta_662f707d; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX celery_taskmeta_662f707d ON celery_taskmeta USING btree (hidden);


--
-- Name: celery_taskmeta_task_id_1efd6ed1da631331_like; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX celery_taskmeta_task_id_1efd6ed1da631331_like ON celery_taskmeta USING btree (task_id varchar_pattern_ops);


--
-- Name: celery_tasksetmeta_662f707d; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX celery_tasksetmeta_662f707d ON celery_tasksetmeta USING btree (hidden);


--
-- Name: celery_tasksetmeta_taskset_id_24b26c359742c9ab_like; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX celery_tasksetmeta_taskset_id_24b26c359742c9ab_like ON celery_tasksetmeta USING btree (taskset_id varchar_pattern_ops);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX django_admin_log_417f1b1c ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX django_admin_log_e8701ad4 ON django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX django_session_de54fa62 ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_461cfeaa630ca218_like; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX django_session_session_key_461cfeaa630ca218_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: djcelery_periodictask_1dcd7040; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX djcelery_periodictask_1dcd7040 ON djcelery_periodictask USING btree (interval_id);


--
-- Name: djcelery_periodictask_f3f0d72a; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX djcelery_periodictask_f3f0d72a ON djcelery_periodictask USING btree (crontab_id);


--
-- Name: djcelery_periodictask_name_47c621f8dc029d22_like; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX djcelery_periodictask_name_47c621f8dc029d22_like ON djcelery_periodictask USING btree (name varchar_pattern_ops);


--
-- Name: djcelery_taskstate_662f707d; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX djcelery_taskstate_662f707d ON djcelery_taskstate USING btree (hidden);


--
-- Name: djcelery_taskstate_863bb2ee; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX djcelery_taskstate_863bb2ee ON djcelery_taskstate USING btree (tstamp);


--
-- Name: djcelery_taskstate_9ed39e2e; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX djcelery_taskstate_9ed39e2e ON djcelery_taskstate USING btree (state);


--
-- Name: djcelery_taskstate_b068931c; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX djcelery_taskstate_b068931c ON djcelery_taskstate USING btree (name);


--
-- Name: djcelery_taskstate_ce77e6ef; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX djcelery_taskstate_ce77e6ef ON djcelery_taskstate USING btree (worker_id);


--
-- Name: djcelery_taskstate_name_4337b4449e8827d_like; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX djcelery_taskstate_name_4337b4449e8827d_like ON djcelery_taskstate USING btree (name varchar_pattern_ops);


--
-- Name: djcelery_taskstate_state_19cb9b39780e399c_like; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX djcelery_taskstate_state_19cb9b39780e399c_like ON djcelery_taskstate USING btree (state varchar_pattern_ops);


--
-- Name: djcelery_taskstate_task_id_29366bc6dcd6fd60_like; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX djcelery_taskstate_task_id_29366bc6dcd6fd60_like ON djcelery_taskstate USING btree (task_id varchar_pattern_ops);


--
-- Name: djcelery_workerstate_f129901a; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX djcelery_workerstate_f129901a ON djcelery_workerstate USING btree (last_heartbeat);


--
-- Name: djcelery_workerstate_hostname_3900851044588416_like; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX djcelery_workerstate_hostname_3900851044588416_like ON djcelery_workerstate USING btree (hostname varchar_pattern_ops);


--
-- Name: jhtdb_dafafield_dataset_0b1f13d3; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX jhtdb_dafafield_dataset_0b1f13d3 ON jhtdb_datafield_dataset USING btree (datafield_id);


--
-- Name: jhtdb_dafafield_dataset_d366d308; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX jhtdb_dafafield_dataset_d366d308 ON jhtdb_datafield_dataset USING btree (dataset_id);


--
-- Name: jhtdb_polycache_d366d308; Type: INDEX; Schema: public; Owner: djuser; Tablespace: 
--

CREATE INDEX jhtdb_polycache_d366d308 ON jhtdb_polycache USING btree (dataset_id);


--
-- Name: auth_content_type_id_508cf46651277a81_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_content_type_id_508cf46651277a81_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissio_group_id_689710a9a73b7457_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_group_id_689710a9a73b7457_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user__permission_id_384b62483d7071f0_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user__permission_id_384b62483d7071f0_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_4b5ed4ffdb8fd9b0_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_4b5ed4ffdb8fd9b0_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permiss_user_id_7f0938558328534a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permiss_user_id_7f0938558328534a_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dj_interval_id_20cfc1cad060dfad_fk_djcelery_intervalschedule_id; Type: FK CONSTRAINT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY djcelery_periodictask
    ADD CONSTRAINT dj_interval_id_20cfc1cad060dfad_fk_djcelery_intervalschedule_id FOREIGN KEY (interval_id) REFERENCES djcelery_intervalschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djan_content_type_id_697914295151027a_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT djan_content_type_id_697914295151027a_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djce_crontab_id_1d8228f5b44b680a_fk_djcelery_crontabschedule_id; Type: FK CONSTRAINT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY djcelery_periodictask
    ADD CONSTRAINT djce_crontab_id_1d8228f5b44b680a_fk_djcelery_crontabschedule_id FOREIGN KEY (crontab_id) REFERENCES djcelery_crontabschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djcelery__worker_id_30050731b1c3d3d9_fk_djcelery_workerstate_id; Type: FK CONSTRAINT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY djcelery_taskstate
    ADD CONSTRAINT djcelery__worker_id_30050731b1c3d3d9_fk_djcelery_workerstate_id FOREIGN KEY (worker_id) REFERENCES djcelery_workerstate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: jhtdb_dafafield_dataset_id_6ddbbb10c454612c_fk_jhtdb_dataset_id; Type: FK CONSTRAINT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY jhtdb_datafield_dataset
    ADD CONSTRAINT jhtdb_dafafield_dataset_id_6ddbbb10c454612c_fk_jhtdb_dataset_id FOREIGN KEY (dataset_id) REFERENCES jhtdb_dataset(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: jhtdb_dataf_datafield_id_68c411ecbdbe208c_fk_jhtdb_datafield_id; Type: FK CONSTRAINT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY jhtdb_datafield_dataset
    ADD CONSTRAINT jhtdb_dataf_datafield_id_68c411ecbdbe208c_fk_jhtdb_datafield_id FOREIGN KEY (datafield_id) REFERENCES jhtdb_datafield(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: jhtdb_polycache_dataset_id_5493d826fcf123c3_fk_jhtdb_dataset_id; Type: FK CONSTRAINT; Schema: public; Owner: djuser
--

ALTER TABLE ONLY jhtdb_polycache
    ADD CONSTRAINT jhtdb_polycache_dataset_id_5493d826fcf123c3_fk_jhtdb_dataset_id FOREIGN KEY (dataset_id) REFERENCES jhtdb_dataset(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

