/* $Id: */
#ifndef MEXLIB_H_
#define MEXLIB_H_

#ifdef  __cplusplus
extern "C" {
#endif

/* MEX function to print error information:
  mexWarnMsgTxt - warn on error
  mexErrMsgTxt  - exit on error */
#define MEX_MSG_TXT mexErrMsgTxt 

#endif
