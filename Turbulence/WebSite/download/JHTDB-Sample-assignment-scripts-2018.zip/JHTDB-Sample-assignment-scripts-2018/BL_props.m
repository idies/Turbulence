%==============================================================
% Local Boundary Layer Thicknesses and U_inf of 2D field
%==============================================================
%
% Usage: [Uinf d99 dstar theta] = BL_props(x,y,Umean);
% where x and y are vectors or
% matrices from read_grid.
% When x and y are matrices, they must be the same size as Z and
% must be increasing
% Uinf is the freestream velocity
% d99 is the boundary layer thickness
% dstar is the displacement thickness
% theta is the momentum thickness

function [Uinf d99 dstar theta x_stat] = BL_props(x,y,Umean)

x_stat=x;
[x,y]=meshgrid(x,y); x=x'; y=y'; 
% Freestream velocity

% Wall normal gradient
xy_inf = zeros(size(x));
for px = 1:size(x,1);
xy_inf(px,:) = gradient(Umean(px,:),y(px,:));
end

xy_inf = xy_inf > -0.002 & xy_inf < 0.002;
xy_inf = imfill(xy_inf,'holes');

Uinf = zeros(size(x,1),1);
for px = 1:size(x,1);
    y_inf = xy_inf(px,:);
    y_inf = y_inf==1;
    Uinf(px,1) = mean(Umean(px,y_inf));
%     a(px) = round(median(y_inf));
%     Uinf(px,1) = Umean(px,a(px));
end

% xy_inf = gradient(Umean)./gradient(y);
% xy_inf = xy_inf > -0.005 & xy_inf < 0.005;
% xy_inf = logical(cumprod(double(xy_inf)));
% y_inf = sum(xy_inf,1) == size(x,1);
% y_inf = median(find(y_inf==1));
% y_inf = round(y_inf);
% % [~,y_inf] = max(sum(xy_inf,1));
% % Find mean freestream velocity in x
% Uinf = Umean(:,y_inf);

% Normalise velocity profiles by U_{\infty}
Umean = Umean./repmat(Uinf,[1,size(Umean,2)]);

% use contour to interpolate for d99
fc = figure;
x_ind = repmat((1:size(x,1))',[1,size(x,2)]);
d = contour(x_ind,y,Umean,[0.99 0.99])';

%nvert = d(1,2);
temp=find(d(:,1)==0.99);
temp2=d(temp,:);
[nvert,b]=max(temp2(:,2));
% nvert(1) = d(1,2);
% nvert(2) = d(nvert(1) + 2,2);
% d = d(2:nvert(1) + nvert(2) + 2,:);

d = d(temp(b)+1:temp(b)+nvert,:);
[~,~,d_ind] = intersect(1:size(Umean,1),d(:,1));
d = d(d_ind,:);
d99 = d(:,2);
d99 = d99(:);
close(fc)

% Displacement thickness and Momentum thickness
for n = 1:size(x,1)

    if ~isnan(any(Umean(n,:)))
    dstar_y = 1-Umean(n,:);
    dstar_y = dstar_y.*(y(n,:) < 1.5*d99(n));
    dstar_y = dstar_y.*(dstar_y > 0);
    dstar(n,1) = trapz(y(n,:),dstar_y);

    theta_y = Umean(n,:).*(1-Umean(n,:));
    theta_y = theta_y.*(y(n,:) < 1.5*d99(n));
    theta_y = theta_y.*(theta_y > 0);
    theta(n,1) = trapz(y(n,:),theta_y);
    end
    
end
end
