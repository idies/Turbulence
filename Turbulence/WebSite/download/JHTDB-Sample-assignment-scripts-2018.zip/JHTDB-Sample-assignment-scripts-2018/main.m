% Matlab script for analysis on turbulent structures
% using Johns Hopkins Turbulence DataBase (JHTDB) channel flow
%
% Written by:
%
% Zhao Wu and Tamer Zaki
% Johns Hopkins University
% Department of Mechanical Engineering
%

clear all;
close all;

addpath('turbmat-20180430');
% ----------------------------------------------------------
% Set maximum number of threads to 1
% ----------------------------------------------------------
maxNumCompThreads(1);

% ----------------------------------------------------------
% Authentication key
% ----------------------------------------------------------

authkey = 'edu.jhu.pha.turbulence.testing-201406';
dataset = 'transition_bl';

% ---- Temporal Interpolation Options ----
NoTInt   = 'None' ; % No temporal interpolation
PCHIPInt = 'PCHIP'; % Piecewise cubic Hermit interpolation in time

% ---- Spatial Interpolation Flags for getVelocity & getVelocityAndPressure ----
NoSInt = 'None'; % No spatial interpolation
Lag4   = 'Lag4'; % 4th order Lagrangian interpolation in space

% ---- Spatial Differentiation & Interpolation Flags for getVelocityGradient & getPressureGradient ----
FD4NoInt = 'None_Fd4' ; % 4th order finite differential scheme for grid values, no spatial interpolation
FD4Lag4  = 'Fd4Lag4'  ; % 4th order finite differential scheme for grid values, 4th order Lagrangian interpolation in space

load('BL_ycoor.mat');
Lx = 969.8465; Nx = 3320;
Lz = 240;      Nz = 2048;
%%
% ///////////////////////////////////////////////////////////
% ////////////// GENERATE A SIMPLE CONTOUR PLOT IN XZ ///////
% ///////////////////////////////////////////////////////////
fprintf('\nGENERATE A SIMPLE CONTOUR PLOT IN XZ\n')
time = 10;
iskip = 10; jskip = 10; kskip = 10;
spacing_x = iskip*(Lx / Nx); % x-spacing
spacing_z = kskip*(Lz / Nz); % z-spacing

% Set domain size and position
clear x y z X Y Z points;
x_min =  100.0;
x_max =  600.0;
nx = int32( (x_max - x_min) / spacing_x);
x = linspace(0, double(nx-1)*spacing_x, nx) + x_min;
% y = ycoor(1:jskip:end);
% ny = length(y);
z_min =    0.0;
z_max =  240.0;
nz = int32( (z_max - z_min) / spacing_z);
z = linspace(0, double(nz-1)*spacing_z, nz) + z_min;
npoints = nx*nz;

yoff = 1;

[X, Z] = meshgrid(x, z);
points = zeros(3,npoints);
points(1,:) = X(:)';
points(2,:) = yoff;
points(3,:) = Z(:)';

% Get the velocity at each point
fprintf('   Requesting velocity at (%ix%i) points...\n',nx, nz);
result3 = getVelocity(authkey, dataset, time, NoSInt, NoTInt, npoints, points);

% Calculate velocity
w = result3(3,:);
w = reshape(w, nz, nx);

% Plot z-velocity contours
figure;
%figure('Position', [0, 0, 570, 200]);
contourf(X, Z, w, 30, 'LineStyle', 'none');
caxis([-0.1 0.1])
daspect([1,1,1])
%colormap(jet);
title('z-velocity', 'FontSize', 13, 'FontWeight', 'bold');
xlabel('x', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('z', 'FontSize', 12, 'FontWeight', 'bold');
colorbar('FontSize', 12);
axis([min(x) max(x) min(z) max(z)]);

%%
% ///////////////////////////////////////////////////////////
% ////////////// PLOT A SIDE VIEW AT SPOT CENTER ////////////
% ///////////////////////////////////////////////////////////
fprintf('\nPLOT A SIDE VIEW AT SPOT CENTER\n')
time = 10;
iskip = 10; jskip = 10; kskip = 10;
spacing_x = iskip*(Lx / Nx); % x-spacing
spacing_z = kskip*(Lz / Nz); % z-spacing

% Set domain size and position
clear x y z X Y Z points;
x_min =  100.0;
x_max =  600.0;
nx = int32( (x_max - x_min) / spacing_x);
x = linspace(0, double(nx-1)*spacing_x, nx) + x_min;
y = ycoor(1:jskip:end);
ny = length(y);
% z_min =    0.0;
% z_max =  240.0;
% nz = int32( (z_max - z_min) / spacing_z);
% z = linspace(0, double(nz-1)*spacing_z, nz) + z_min;
npoints = nx*ny;

zoff = 115;

[X, Y] = meshgrid(x, y);
points = zeros(3,npoints);
points(1,:) = X(:)';
points(2,:) = Y(:)';
points(3,:) = zoff;

% Get the velocity at each point
fprintf('   Requesting velocity at (%ix%i) points...\n',nx, ny);
result3 = getVelocity(authkey, dataset, time, NoSInt, NoTInt, npoints, points);

% Calculate z-velocity
w = result3(3,:);
w = reshape(w, ny, nx);

% Plot z-velocity contours
figure;
%figure('Position', [0, 0, 570, 200]);
contourf(X, Y, w, 30, 'LineStyle', 'none');
%hold on;
%plot(x_stat(),d99,'w--');
caxis([-0.1 0.1])
daspect([1,1,1])
%colormap(jet);
title('z-velocity', 'FontSize', 13, 'FontWeight', 'bold');
xlabel('x', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('y', 'FontSize', 12, 'FontWeight', 'bold');
colorbar('FontSize', 12);
axis([min(x) max(x) min(y) max(y)]);

%%
% ///////////////////////////////////////////////////////////
% ////////////// PLOT AN END VIEW AT SPOT CENTER ////////////
% ///////////////////////////////////////////////////////////
fprintf('\nPLOT AN END VIEW AT SPOT CENTER\n')
time = 10;
iskip = 10; jskip = 10; kskip = 10;
spacing_x = iskip*(Lx / Nx); % x-spacing
spacing_z = kskip*(Lz / Nz); % z-spacing

% Set domain size and position
clear x y z X Y Z points;
% x_min =  100.0;
% x_max =  600.0;
% nx = int32( (x_max - x_min) / spacing_x);
% x = linspace(0, double(nx-1)*spacing_x, nx) + x_min;
y = ycoor(1:jskip:end);
ny = length(y);
z_min =    0.0;
z_max =  240.0;
nz = int32( (z_max - z_min) / spacing_z);
z = linspace(0, double(nz-1)*spacing_z, nz) + z_min;
npoints = nz*ny;

xoff = 270;

[Y, Z] = meshgrid(y, z);
points = zeros(3,npoints);
points(1,:) = xoff;
points(2,:) = Y(:)';
points(3,:) = Z(:)';

% Get the velocity at each point
fprintf('   Requesting velocity at (%ix%i) points...\n',ny, nz);
result3 = getVelocity(authkey, dataset, time, NoSInt, NoTInt, npoints, points);

% Calculate z-velocity
w = result3(3,:);
w = reshape(w, nz, ny);

% Plot z-velocity contours
figure;
%figure('Position', [0, 0, 570, 200]);
contourf(Z, Y, w, 30, 'LineStyle', 'none');
caxis([-0.1 0.1])
daspect([1,1,1])
%colormap(jet);
title('z-velocity', 'FontSize', 13, 'FontWeight', 'bold');
xlabel('z', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('y', 'FontSize', 12, 'FontWeight', 'bold');
colorbar('FontSize', 12);
axis([min(z) max(z) min(y) max(y)]);

%%
% ///////////////////////////////////////////////////////////
% ////////////// PLOT WALL SHEAR STRESS /////////////////////
% ///////////////////////////////////////////////////////////
fprintf('\nPLOT WALL SHEAR STRESS\n');
time = 10;
iskip = 10; jskip = 10; kskip = 10;
spacing_x = iskip*(Lx / Nx); % x-spacing
spacing_z = kskip*(Lz / Nz); % z-spacing

% Set domain size and position
clear x y z X Y Z points;
x_min =  100.0;
x_max =  600.0;
nx = int32( (x_max - x_min) / spacing_x);
x = linspace(0, double(nx-1)*spacing_x, nx) + x_min;
% y = ycoor(1:jskip:end);
% ny = length(y);
z_min =    0.0;
z_max =  240.0;
nz = int32( (z_max - z_min) / spacing_z);
z = linspace(0, double(nz-1)*spacing_z, nz) + z_min;
npoints = nx*nz;

yoff = 0;

[X, Z] = meshgrid(x, z);
points = zeros(3,npoints);
points(1,:) = X(:)';
points(2,:) = yoff;
points(3,:) = Z(:)';

% Get the velocity at each point
fprintf('   Requesting velocity gradients at (%ix%i) points...\n',nx, nz);
result9 = getVelocityGradient(authkey, dataset, time, FD4NoInt, NoTInt, npoints, points);

% Calculate Cf
dudy = result9(2,:);
dudy = reshape(dudy, nz, nx);
nu = 1/800;
Cf = 2*nu*dudy;

% Plot Cf contours
f = figure;
%figure('Position', [0, 0, 570, 200]);
subplot(2,2,[1 2])
contourf(X, Z, Cf, 30, 'LineStyle', 'none');
caxis([0 0.01])
daspect([1,1,1])
%colormap(jet);
title('Skin friction coefficient', 'FontSize', 13, 'FontWeight', 'bold');
xlabel('x', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('z', 'FontSize', 12, 'FontWeight', 'bold');
colorbar('FontSize', 12);
axis([min(x) max(x) min(z) max(z)]);

subplot(2,2,3)
plot(x,mean(Cf,1))
title('Averaged skin friction coefficient', 'FontSize', 13, 'FontWeight', 'bold');
xlabel('x', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('\langle Cf \rangle', 'FontSize', 12, 'FontWeight', 'bold');

%%
% ///////////////////////////////////////////////////////////
% ////////////// PLOT MEAN PROFILES /////////////////////////
% ///////////////////////////////////////////////////////////
fprintf('\nPLOT MEAN PROFILES\n')
time = 10;
iskip = 20; jskip = 10; kskip = 20;
spacing_x = iskip*(Lx / Nx); % x-spacing
spacing_z = kskip*(Lz / Nz); % z-spacing

% Set domain size and position
clear x y z X Y Z points;
x_min =  100.0;
x_max =  600.0;
nx = int32( (x_max - x_min) / spacing_x);
x = linspace(0, double(nx-1)*spacing_x, nx) + x_min;
y = ycoor(1:jskip:end)';
ny = length(y);
z_min =    0.0;
z_max =  240.0;
nz = int32( (z_max - z_min) / spacing_z);
z = linspace(0, double(nz-1)*spacing_z, nz) + z_min;
npoints = nx*ny*nz;

%yoff = 0;

[Y, X, Z] = meshgrid(y, x, z);
points=zeros(3,npoints);
points(1,:) = X(:)';
points(2,:) = Y(:)';
points(3,:) = Z(:)';

% Get the velocity at each point
fprintf('   Requesting velocity at (%ix%ix%i) points...\n', nx, ny, nz);
result3 = getVelocity(authkey, dataset, time, NoSInt, NoTInt, npoints, points);

% Calculate d99, dstar, theta
u = result3(1,:);
u = reshape(u, nx, ny, nz);
um = mean(u,3);
[Uinf d99 dstar theta x_stat] = BL_props(x,y,um);

% Plot d99, dstar, theta
figure(f)
subplot(2,2,4)
plot(x_stat,d99,'-',x_stat,dstar,'--',x_stat,theta,'-.')
title('Boundary Layer Thicknesses', 'FontSize', 13, 'FontWeight', 'bold');
xlabel('x', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('y', 'FontSize', 12, 'FontWeight', 'bold');
legend('\delta_{99}','\delta^*','\theta')

%%
% ///////////////////////////////////////////////////////////
% ////////////// SPOT DETECTION /////////////////////////////
% ///////////////////////////////////////////////////////////
% The current streak detection is a simplified introductory version.
% The details of the algorithm can be found in:
%
%   Nolan & Zaki (J. Fluid Mech., Vol 728, pp. 306-339, 2013)
%
fprintf('\nSPOT DETECTION\n')
time = 10;
iskip = 10; jskip = 10; kskip = 10;
spacing_x = iskip*(Lx / Nx); % x-spacing
spacing_z = kskip*(Lz / Nz); % z-spacing

% Set domain size and position
clear x y z X Y Z points;
x_min =  220.0;
x_max =  360.0;
nx = int32( (x_max - x_min) / spacing_x);
x = linspace(0, double(nx-1)*spacing_x, nx) + x_min;
% y = ycoor(1:jskip:end);
% ny = length(y);
z_min =   0.0;
z_max =  240.0;
nz = int32( (z_max - z_min) / spacing_z);
z = linspace(0, double(nz-1)*spacing_z, nz) + z_min;
z1 = z(44:129);
npoints = nx*nz;

yoff = 1;

[X, Z] = meshgrid(x, z);
points = zeros(3,npoints);
points(1,:) = X(:)';
points(2,:) = yoff;
points(3,:) = Z(:)';

% Get the velocity at each point
fprintf('   Requesting velocity at (%ix%i) points...\n',nx, nz);
result3 = getVelocity(authkey, dataset, time, NoSInt, NoTInt, npoints, points);

% Calculate v, w, v', w', |v'|+|w'| and Otsu's threshold
v = result3(2,:); v = reshape(v, nz, nx);
w = result3(3,:); w = reshape(w, nz, nx);

vm = (mean(v,1))/3;
vm = repmat(vm,129-44+1,1);
vp = v(44:129,:)-vm ;
wp = w(44:129,:);
f = abs(vp)+abs(wp);

temp = mat2gray(f); th=graythresh(temp);

% Calculate the turbulent spot and the area of turbulent spot
IFUN = mat2gray(f)>th;
SE = strel('disk',1);
IFUN = imclose(IFUN,SE);
IFUN = imopen(IFUN,SE) ;
IFUN = imfill(IFUN,'holes');
IFUN = bwareafilt(IFUN,1,4);

temp = bwboundaries(IFUN,'noholes');
s1 = cal_area(x(temp{1}(:,2)),z1(temp{1}(:,1)));

% Plot z-velocity contours
figure;
%figure('Position', [0, 0, 570, 200]);
contourf(x, z1, f, 30, 'LineStyle', 'none');
hold on;
contour(x, z1, IFUN, [1 1], 'k-');
caxis([-0.1 0.1])
daspect([1,1,1])
%colormap(jet);
title(['TNTI, area=',num2str(s1)], 'FontSize', 13, 'FontWeight', 'bold');
xlabel('x', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('z', 'FontSize', 12, 'FontWeight', 'bold');
colorbar('FontSize', 12);
axis([min(x) max(x) min(z1) max(z1)]);

%%
% ///////////////////////////////////////////////////////////
% ////////////// STREAK DETECTION ///////////////////////////
%////////////////////////////////////////////////////////////
% The current streak detection is a simplified introductory version.
% The details of the algorithm can be found in:
%
%   Nolan & Zaki (J. Fluid Mech., Vol 728, pp. 306-339, 2013)
%   Lee et al., (J. Fluid Mech., Vol., 749, pp. 818-840, 2014)
%
fprintf('\nSTREAK DETECTION\n')
time = 10;
iskip = 4; jskip = 2; kskip = 12;
spacing_x = iskip*(Lx / Nx); % x-spacing
spacing_z = kskip*(Lz / Nz); % z-spacing

% Set domain size and position
clear x y z X Y Z points;
x_min =  100.0;
x_max =  200.0;
nx = int32( (x_max - x_min) / spacing_x);
x = linspace(0, double(nx-1)*spacing_x, nx) + x_min;
xoff = 150;
%d99q = interp1(x_stat,d99,xoff);
%[~,yi] = min(abs(ycoor-d99q));
%y = ycoor(1:jskip:yi*0.8);
ny = 40;
y = linspace(ycoor(1), mean(d99)*0.8, ny);
z_min =    0.0;
z_max =  240.0;
nz = int32( (z_max - z_min) / spacing_z);
z = linspace(0, double(nz-1)*spacing_z, nz) + z_min;
npoints = nz*ny*nx;

[Y, X, Z] = meshgrid(y, x, z);
points = zeros(3,npoints);
points(1,:) = X(:)';
points(2,:) = Y(:)';
points(3,:) = Z(:)';

% Get the velocity at each point
fprintf('   Requesting velocity at (%ix%ix%i) points...\n', nx, ny, nz);
result3 = getVelocity(authkey, dataset, time, Lag4, NoTInt, npoints, points);

% Calculate u' and use Gaussian filter
u = result3(1,:);
u = reshape(u, nx, ny, nz);
um = mean(u,3);
up = u-repmat(um,1,1,nz);

up_filter = imgaussfilt3(up,2);

% Threshold correction after elimination of small-scales
U_threshold = 0.1;
U_filter_threshold = zeros(ny,1);
for j = 1 : ny
    uu_xz = mean(mean(up(:,j,:).*up(:,j,:),3),1);
    uu_filter_xz = mean(mean(up(:,j,:).*up_filter(:,j,:),3),1);
    U_filter_threshold(j) = ( uu_filter_xz / uu_xz ) * U_threshold;
end

% Local extrema in the cross-flow plane
loc_max=false(size(up));
loc_min=false(size(up));
for i = 1 : nx
    temp = squeeze(up_filter(i,:,:));
    loc_max(i,:,:) = imregionalmax(temp);
    loc_min(i,:,:) = imregionalmax(-temp);
end
loc_max(:,[1 end],:) = 0; loc_max(:,:,[1 end]) = 0;
loc_min(:,[1 end],:) = 0; loc_min(:,:,[1 end]) = 0;

% Streak cores in the cross-flow plane
pos_streak = false(size(up));
neg_streak = false(size(up));
for j = 2 : ny-1
    pos_streak(:,j,:) = loc_max(:,j,:) & up_filter(:,j,:)> U_filter_threshold(j);
    neg_streak(:,j,:) = loc_min(:,j,:) & up_filter(:,j,:)<-U_filter_threshold(j);
end
[row1,col1] = find(squeeze(pos_streak(10,:,:)));
[row2,col2] = find(squeeze(neg_streak(10,:,:)));
up_at_streak_core = up_filter(find(pos_streak | neg_streak));

% Plot filtered u' contours, streak cores and PDF of u' at streak cores
figure;
%figure('Position', [0, 0, 570, 200]);
subplot(2,1,1)
contourf(z,y,squeeze(up_filter(10,:,:)), 30, 'LineStyle', 'none');
hold on;
h1 = plot(z(col1),y(row1),'r+');
h2 = plot(z(col2),y(row2),'bx');
caxis([-0.05 0.05])
daspect([6,1,1])
%colormap(jet);
title(['u'' at x=',num2str(x(10))], 'FontSize', 13, 'FontWeight', 'bold');
h3 = legend([h1,h2],'positive streak core','negative streak core');
h3.Position=[0.6 0.83 0.2857 0.0869];
xlabel('z', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('y', 'FontSize', 12, 'FontWeight', 'bold');
colorbar('FontSize', 12);
axis([min(z) max(z) min(y) max(y)]);

subplot(2,1,2)
histogram(up_at_streak_core)
xlabel('u''', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('P.D.F', 'FontSize', 12, 'FontWeight', 'bold');