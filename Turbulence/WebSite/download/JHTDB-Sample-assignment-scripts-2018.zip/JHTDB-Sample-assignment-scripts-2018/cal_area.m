function [ar] = cal_area(xcoor,ycoor)
% calculate the area of a closed polygon
if (length(xcoor)>=3)
    ar = sum((ycoor(1:end-1).*xcoor(2:end)-xcoor(1:end-1).*ycoor(2:end)));
    ar = ar+(ycoor(end)*xcoor(1)-xcoor(end)*ycoor(1));
    ar = ar/2;
    if (ar==0)
        ar = NaN;
    end
else
    ar = NaN;
end
ar = abs(ar);
end

