%
% Turbmat - a Matlab library for the JHU Turbulence Database Cluster
%   
% Sample code, part of Turbmat
%

%
% Written by:
%  
% Perry Johnson
% The Johns Hopkins University
% Department of Mechanical Engineering
% pjohns86@jhu.edu, johnson.perry.l@gmail.com
%

%
% This file is part of Turbmat.
% 
% Turbmat is free software: you can redistribute it and/or modify it under
% the terms of the GNU General Public License as published by the Free
% Software Foundation, either version 3 of the License, or (at your option)
% any later version.
% 
% Turbmat is distributed in the hope that it will be useful, but WITHOUT
% ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
% FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
% more details.
% 
% You should have received a copy of the GNU General Public License along
% with Turbmat.  If not, see <http://www.gnu.org/licenses/>.
%

clear all;
close all;

authkey = 'edu.jhu.cs.kalin-cf747456';
dataset = 'mhd1024';

% ---- Temporal Interpolation Options ----
NoTInt   = 'None' ; % No temporal interpolation
PCHIPInt = 'PCHIP'; % Piecewise cubic Hermit interpolation in time

% ---- Spatial Interpolation Flags for getVelocity &amp; getVelocityAndPressure ----
NoSInt = 'None'; % No spatial interpolation
Lag4   = 'Lag4'; % 4th order Lagrangian interpolation in space
Lag6   = 'Lag6'; % 6th order Lagrangian interpolation in space
Lag8   = 'Lag8'; % 8th order Lagrangian interpolation in space

% ---- Spatial Differentiation &amp; Interpolation Flags for getVelocityGradient &amp; getPressureGradient ----
FD4NoInt = 'None_Fd4' ; % 4th order finite differential scheme for grid values, no spatial interpolation
FD6NoInt = 'None_Fd6' ; % 6th order finite differential scheme for grid values, no spatial interpolation
FD8NoInt = 'None_Fd8' ; % 8th order finite differential scheme for grid values, no spatial interpolation
FD4Lag4  = 'Fd4Lag4'  ; % 4th order finite differential scheme for grid values, 4th order Lagrangian interpolation in space

%  Set time step to sample
time = 0.364;

spacing = 2.0*pi/1023;

threshold_field = 'vorticity';
threshold = 65.0;
X = int32(0); 
Y = int32(0);
Z = int32(0);
Xwidth = int32(256);
Ywidth = int32(256);
Zwidth = int32(256);

% Requesting vorticity threshold.
threshold_array =  getThreshold (authkey, 'isotropic1024', 'vorticity', ...
    time, 65.0, FD4NoInt, X, Y, Z, Xwidth, Ywidth, Zwidth);
% Determine maximum value of the vorticity.
[M,I] = max(threshold_array(4,:));
% Set domain size and position for JHTDB request.
nx = 128; ny = nx;
xoff = (threshold_array(1,I) - nx/2)*spacing; 
yoff = (threshold_array(2,I) - ny/2)*spacing;
zoff = threshold_array(3,I);
npoints = nx*ny;
% Create surface.
x = linspace(0, (nx-1)*spacing, nx) + xoff;
y = linspace(0, (ny-1)*spacing, ny) + yoff;
[X Y] = meshgrid(x, y);
points(1:2,:) = [X(:)'; Y(:)'];
points(3,:) = zoff*spacing;
% Get the velocity gradient at each point.
gradient = getVelocityGradient (authkey, 'isotropic1024', time,  ...
    FD4Lag4, NoTInt, npoints, points);
% Calculate vorticity magnitude.
vort = [gradient(8,:) - gradient(6,:); gradient(3,:) - ...
    gradient(7,:); gradient(4,:) - gradient(2,:);];
vort_mag = sqrt(vort(1,:).^2 + vort(2,:).^2 + vort(3,:).^2);
VortMag = transpose(reshape(vort_mag, nx, ny));

% Plot vorticity magnitude contours.
contourf(X, Y, VortMag, 30, 'LineStyle', 'none');
set(gca, 'FontSize', 11)
title('Vorticity Magnitude', 'FontSize', 13, 'FontWeight', 'bold');
xlabel('x', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('y', 'FontSize', 12, 'FontWeight', 'bold');
colorbar('FontSize', 12);
axis([xoff max(x) yoff max(y)]);
set(gca, 'TickDir', 'out', 'TickLength', [.02 .02],'XMinorTick', 'on', 'YMinorTick', 'on');



Q_criterion = abs([gradient(1,:).*gradient(5,:) + gradient(5,:).*gradient(9,:) + gradient(1,:).*gradient(9,:) - ...
    gradient(2,:).*gradient(4,:) - gradient(6,:).*gradient(8,:) - gradient(3,:).*gradient(7,:)]);
Qabs = transpose(reshape(Q_criterion, nx, ny));
